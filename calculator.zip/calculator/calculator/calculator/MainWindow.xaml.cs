﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace calculator
{
    public partial class MainWindow : Window
    {
        private string[] muveletek = { "+", "-", "x", "/" };
        private int currentMuveletIndex = 0;

        public MainWindow()
        {
            InitializeComponent();
            Művelet.Text = muveletek[currentMuveletIndex];
        }

        private void bNöv_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(Szám1.Text, out int currentValue))
            {
                Szám1.Text = (currentValue + 1).ToString();
            }
            else
            {
                Szám1.Text = "1";
            }
        }

        private void bCsökk_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(Szám1.Text, out int currentValue))
            {
                Szám1.Text = (currentValue - 1).ToString();
            }
            else
            {
                Szám1.Text = "-1";
            }
        }

        private void jNöv_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(Szám2.Text, out int currentValue))
            {
                Szám2.Text = (currentValue + 1).ToString();
            }
            else
            {
                Szám2.Text = "1";
            }
        }

        private void jCsökk_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(Szám2.Text, out int currentValue))
            {
                Szám2.Text = (currentValue - 1).ToString();
            }
            else
            {
                Szám2.Text = "-1";
            }
        }

        private void Változó_Click(object sender, RoutedEventArgs e)
        {
            currentMuveletIndex = (currentMuveletIndex + 1) % muveletek.Length;
            Művelet.Text = muveletek[currentMuveletIndex];
        }

        private void Számol_Click(object sender, RoutedEventArgs e)
        {
            // Ellenőrzés, hogy az értékek meg vannak-e adva
            if (string.IsNullOrWhiteSpace(Szám1.Text) || string.IsNullOrWhiteSpace(Szám2.Text) || string.IsNullOrWhiteSpace(Művelet.Text))
            {
                TreeViewItem warningItem = new TreeViewItem();
                warningItem.Header = "Adja meg az értékeket!";
                Eredmény.Items.Clear();
                Eredmény.Items.Add(warningItem);
                return;
            }

            // Számítás elvégzése
            if (double.TryParse(Szám1.Text, out double szám1) && double.TryParse(Szám2.Text, out double szám2))
            {
                double eredmény = 0;

                switch (Művelet.Text)
                {
                    case "+":
                        eredmény = szám1 + szám2;
                        break;
                    case "-":
                        eredmény = szám1 - szám2;
                        break;
                    case "x":
                        eredmény = szám1 * szám2;
                        break;
                    case "/":
                        if (szám2 == 0)
                        {
                            TreeViewItem errorItem = new TreeViewItem();
                            errorItem.Header = "Nem lehet nullával osztani!";
                            Eredmény.Items.Clear();
                            Eredmény.Items.Add(errorItem);
                            return;
                        }
                        eredmény = szám1 / szám2;
                        break;
                    default:
                        TreeViewItem unknownOpItem = new TreeViewItem();
                        unknownOpItem.Header = "Ismeretlen művelet!";
                        Eredmény.Items.Clear();
                        Eredmény.Items.Add(unknownOpItem);
                        return;
                }

                // Eredmény megjelenítése
                TreeViewItem resultItem = new TreeViewItem();
                resultItem.Header = $"Eredmény: {eredmény}";
                Eredmény.Items.Clear();
                Eredmény.Items.Add(resultItem);
            }
            else
            {
                // Hiba esetén figyelmeztetés
                TreeViewItem formatErrorItem = new TreeViewItem();
                formatErrorItem.Header = "Helytelen számformátum!";
                Eredmény.Items.Clear();
                Eredmény.Items.Add(formatErrorItem);
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {
        }
    }
}
