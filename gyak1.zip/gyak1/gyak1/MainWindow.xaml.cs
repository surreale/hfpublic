﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using static Org.BouncyCastle.Crypto.Engines.SM2Engine;


namespace gyak1
{
    public class Payment
    {
        public static string connectiondata = "server = localhost; database = nov27; uid = spn; pwd = 12345";

        public void Ask(ListBox lista)
        {
            try
            {
                MySqlConnection connection = new MySqlConnection(connectiondata);
                connection.Open();
                string query = "SELECT fizetesmod FROM fizetesmod";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader = cmd.ExecuteReader();

                lista.Items.Clear();

                while (reader.Read())
                {
                    lista.Items.Add(reader[0]);
                }
            }
            catch
            {
                MessageBox.Show("Adatbázis kapcsolati hiba!", "Hiba!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_edit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_del_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}